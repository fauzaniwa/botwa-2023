// let fs = require('fs')
// const { MessageType } = require('@adiwajshing/baileys')
// let handler = async (m, { conn }) => {
// let helloaine = fs.readFileSync('./mp3/halo.opus') 
// conn.sendFile(m.chat, helloaine, '', '', m, true)
// //conn.sendMessage(m.chat, helloaine, MessageType.audio, {quoted: m, mimetype: 'audio/mp4', ptt:true})
// // await conn.sendMessage(m.chat, { audio: { url: helloaine }, mimetype: 'audio/mp4'}, m)
// }

// handler.customPrefix = /^(hi|hii|hiii|hi iwa|hii iwa|hiii iwa|hy|halo|hallo|helo|hello|hy iwa|halo iwa|hallo iwa|helo iwa|hello iwa)$/i
// handler.customPrefix = /^(hi|hii|hiii|hi iwa|hii iwa|hiii iwa|hy|halo|hallo|helo|hello|hy iwa|halo iwa|hallo iwa|helo iwa|hello iwa|hai|haii|haiii|hai iwa|)$/i
// handler.command = new RegExp

// handler.limit = true
// handler.mods = false 
// handler.premium = false
// handler.group = false
// handler.private = false

// module.exports = handler
